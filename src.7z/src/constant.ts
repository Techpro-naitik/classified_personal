export enum End_Point {

    server_Url= 'https://classifiedwebapi.azurewebsites.net/api/'
}

export enum urL {

    Admin = 'Admin/',
    Authentication ='Authentication/',
    Products = 'Products/',
    AdminAnalytics = 'AdminAnalytics/'

}

export enum auth_Urls {
    login = 'login',
    Register='Register',
    GetAllCategory = 'GetAllCategory',
    GetSubCategory = 'GetSubCategoriesOfCategory?CategoryID=',
    SignOut = 'SignOut',
    ForgetPasswordEmail ='ForgetPassword?email=',
    ResetPasswordUsername = 'ResetPassword?username=',
    getPasswordResetTokenEmail = 'getPasswordResetToken?email=',
    GetProfileDetailsUsername = 'GetProfileDetails?username=',
    GetCategoryID = 'GetCategory?id=',
    ResetPassword = 'ResetPassword?username=',
    previousPassword = '&previouspassword=',
    newPassword= '&newpassword=',
    ProductALLProduct ="GetAllProducts",
    FilterResult = 'FilterResult',
    GetLocationsList = 'GetLocationsList',
    NewPassword = 'NewPassword',
    AddProduct = 'AddProduct',
    GetAllbrands = 'GetAllbrands',
    GetAllbrandswithsubcategoryid='GetAllbrandswithsubcategoryid?subcategoryid=',
    GateMakeYears = 'GateMakeYears',
    GetAllProductModels = 'GetAllProductModels',
    SearchProducts = 'SearchProducts?Keywords=',
    AddSearchedKeyword = 'AddSearchedKeyword?keyword=',
    VerifyMobileNumber ='VerifyMobileNumber?number=',
    GetAllCategoryTypes = 'GetAllCategoryTypes',
    GetAllChildSubCategory = 'GetAllChildSubCategory'
}

            