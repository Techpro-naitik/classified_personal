import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dailyfeeds',
  templateUrl: './dailyfeeds.component.html',
  styleUrls: ['./dailyfeeds.component.css']
})
export class DailyfeedsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
