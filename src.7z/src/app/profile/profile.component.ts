import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbDate, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
// import {AgmMap, MapsAPILoader  } from '@agm/core';  

@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.scss']
})


export class ProfileComponent implements OnInit {
    getDataFormLocal_local: string;
    getDataFormLocal_gmail: string;
    getDataFormLocal_fb: string;
    fromDate: NgbDate;
    toDate: NgbDate;
    hoveredDate: NgbDate;
    closeResult: string;
    model1 : NgbDate;
    model2 : NgbDate;


    latitude = 51.678418;
    longitude = 7.809007;

    // @ViewChild(AgmMap,{static: true}) public agmMap: AgmMap;  

    // items = ['item1', 'item2', 'item3', 'item4'];
    focus;
    focus1;
    focus2;
    focus3;
    focus4;
  zoom: number;
//   lat: number=51.678418;
//   lng: number=7.809007;
  getAddress: any;
    lng: number;
    lat: number;

    constructor(
        public router:Router,
        private modalService: NgbModal, 
        calendar: NgbCalendar,
        // private apiloader: MapsAPILoader  
    ) { }

    ngOnInit() {
    
      // this.agmMap.triggerResize(true);  
      //  this.zoom = 16;  
      //  navigator.geolocation.getCurrentPosition( pos => {
      //   this.lng = +pos.coords.longitude;
      //   this.lat = +pos.coords.latitude;
      //   console.log( this.lng)
      //   console.log( this.lat)
      //   let location = new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude);
      //   console.log(location)
        // this.map.panTo(location);

      // });



        this.getDataFormLocal_local = JSON.parse(localStorage.getItem('LoginResponse'))
        this.getDataFormLocal_gmail = JSON.parse(localStorage.getItem('gmailLogin'))
        this.getDataFormLocal_fb = JSON.parse(localStorage.getItem('fbLogin'))
        console.log(this.getDataFormLocal_local)
        console.log(this.getDataFormLocal_gmail)
        console.log(this.getDataFormLocal_fb)
        if( this.getDataFormLocal_fb==null){
            this.router.navigate['/home']
        }
                
    }

    open(content, type, modalDimension) {
        if (modalDimension === 'sm' && type === 'modal_mini') {
            this.modalService.open(content, { windowClass: 'modal-mini', size: 'sm', centered: true }).result.then((result) => {
                this.closeResult = `Closed with: ${result}`;
            }, (reason) => {
                this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
            });
        } else if (modalDimension === '' && type === 'Notification') {
          this.modalService.open(content, { windowClass: 'modal-danger', centered: true }).result.then((result) => {
              this.closeResult = `Closed with: ${result}`;
          }, (reason) => {
              this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
          });
        } else {
            this.modalService.open(content,{ centered: true }).result.then((result) => {
                this.closeResult = `Closed with: ${result}`;
            }, (reason) => {
                this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
            });
        }
    }
  
    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return  `with: ${reason}`;
        }
    }
    isRangeStart(date: NgbDate){
      return this.model1 && this.model2 && date.equals(this.model1);
    }
    isRangeEnd(date: NgbDate){
      return this.model1 && this.model2 && date.equals(this.model2);
    }
    isInRange(date: NgbDate){
      return date.after(this.model1) && date.before(this.model2);
    }
    isActive(date: NgbDate){
      return date.equals(this.model1) || date.equals(this.model2);
    }
    endDateChanged(date){
      if (this.model1 && this.model2 && (this.model1.year > this.model2.year || this.model1.year === this.model2.year && this.model1.month > this.model2.month || this.model1.year === this.model2.year && this.model1.month === this.model2.month && this.model1.day > this.model2.day )) {
        this.model1 = this.model2;
      }
    }
    startDateChanged(date){
      if (this.model1 && this.model2 && (this.model1.year > this.model2.year || this.model1.year === this.model2.year && this.model1.month > this.model2.month || this.model1.year === this.model2.year && this.model1.month === this.model2.month && this.model1.day > this.model2.day )) {
        this.model2 = this.model1;
      }
    }
//     get() {  
//       if (navigator.geolocation) {  
//           navigator.geolocation.getCurrentPosition((position: Position) => {  
//               if (position) {  
//                   this.lat = position.coords.latitude;  
//                   this.lng = position.coords.longitude;  
//                   this.getAddress = (this.lat, this.lng)  
//                   console.log(position)  
//                   this.apiloader.load().then(() => {  
//                       let geocoder = new google.maps.Geocoder;  
//                       let latlng = {  
//                           lat: this.lat,  
//                           lng: this.lng  
//                       };  
//                       geocoder.geocode({  
//                           'location': latlng  
//                       }, function(results) {  
//                           if (results[0]) {  
//                               this.currentLocation = results[0].formatted_address;  
//                               console.log(this.assgin);  
//                           } else {  
//                               console.log('Not found');  
//                           }  
//                       });  
//                   });  
//               }  
//           })  
//       }  
//   }   
//   mapClicked($event: MouseEvent) {  
//     this.latitude = $event.coords.lat,  
//         this.longitude = $event.coords.lng  
//     this.apiloader.load().then(() => {  
//         let geocoder = new google.maps.Geocoder;  
//         let latlng = {  
//             lat: this.latitude,  
//             lng: this.longitude  
//         };  
//         geocoder.geocode({  
//             'location': latlng  
//         }, function(results) {  
//             if (results[0]) {  
//                 this.currentLocation = results[0].formatted_address;  
//                 console.log(this.currentLocation);  
//             } else {  
//                 console.log('Not found');  
//             }  
//         });  
//     });  
// }
}
